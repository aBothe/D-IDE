This archive contains an updater that downloads the latest d-ide binary files from the online repository and extracts them to the current directory.

Note that the IDE is still in development and many features are untested and often unstable.

For feature requests visit http://sourceforge.net/tracker/?group_id=301390&atid=1270931 